import java.util.ArrayList;

public class MazeSolver {


    public static boolean solveMaze(char[][] maze, int row, int col, ArrayList<String> path, MazeVisualizer visualizer) {

        // Checking for out of bounds or if the cell is a wall or already visited
        if (isOutOfBoundsOrInvalid(maze, row, col)) {
            // This condition checks if the current cell is out of the maze's boundaries,
            // or if it's a wall ('#') or a previously visited cell ('+')
            return false;
            // If it is, we can't move here, so returns false
        }

        // Check if we've reached the end
        // This checks if the current cell is the exit ('E')
        if (maze[row][col] == 'E') {
            return true;  // If it is then we've found the exit, so return true
        }

        // Mark this cell as visited
        // Set the current cell as visited by marking it with '+'
        markingVisited(maze, row, col, visualizer);

        // Try moving in all directions: down, right, up, left
        // Attempting to move down
        if (tryMove(maze, row + 1, col, path, visualizer, "down"))
            return true;  // If moving down leads to a solution, return true

        // Attempting to move right
        if (tryMove(maze, row, col + 1, path, visualizer, "right"))
            return true;  // If moving right leads to a solution, return true

        // Attempting to move up
        if (tryMove(maze, row - 1, col, path, visualizer, "up"))
            return true;  // If moving up leads to a solution, return true

        // Attempting to move left
        if (tryMove(maze, row, col - 1, path, visualizer, "left"))
            return true;  // If moving left leads to a solution, return true

        // Unvisited this cell (backtrack)
        // If none of the moves work, unmarked the cell and backtrack
        makingUnvisited(maze, row, col, visualizer);

        return false;  // Return false if no solution is found
    }

    // Helper method to check if a cell is out of bounds or invalid
    private static boolean isOutOfBoundsOrInvalid(char[][] maze, int row, int col) {
        // Check if the cell is outside the maze boundaries or if it is a wall or already visited
        return row < 0 || col < 0 || row >= maze.length || col >= maze[0].length || maze[row][col] == '#' || maze[row][col] == '+';
    }

    // Helper method to mark a cell as visited and update visualization
    private static void markingVisited(char[][] maze, int row, int col, MazeVisualizer visualizer) {
        maze[row][col] = '+';  // Mark the cell as visited
        visualizer.repaint();  // Updating the visual representation
        try {
            Thread.sleep(100);  // to Pause for a brief moment to visualize the step
        } catch (InterruptedException e) {
            e.printStackTrace();  // Print stack trace if an interruption occurs
        }
    }

    // Helper method to unmarked a cell and making it unvisited and update visualization
    private static void makingUnvisited(char[][] maze, int row, int col, MazeVisualizer visualizer) {
        maze[row][col] = ' ';  // Unmarked the cell
        visualizer.repaint();  // Updating the visual representation
        try {
            Thread.sleep(100);  // to Pause for a brief moment to visualize the step
        } catch (InterruptedException e) {
            e.printStackTrace();  // Print stack trace if an interruption occurs
        }
    }

    // Helper method to attempt moving in a direction
    private static boolean tryMove(char[][] maze, int newRow, int newCol, ArrayList<String> path, MazeVisualizer visualizer, String direction) {
        // Try to solve the maze from the new cell position
        if (solveMaze(maze, newRow, newCol, path, visualizer)) {
            path.add(direction);  // If successful, add the direction to the path
            return true;  // Return true
            // if the move leads to a solution
        }
        return false;  // Return false
        // if the move doesn't lead to a solution
    }

    public static void main(String[] args) {
        Maze maze = new Maze("maze1.txt"); // to change the maze you're solving, change this filename (maze1.txt, maze2.txt, maze3.txt, maze4.txt, or maze5.txt)
        maze.printMaze();

        ArrayList<String> path = new ArrayList<>();

        // create a frame to display the maze
        MazeVisualizer visualizer = new MazeVisualizer(maze.getMaze(), path);
        visualizer.display();

        if (solveMaze(maze.getMaze(), maze.getStartRow(), maze.getStartCol(), path, visualizer)) {
            System.out.println("Maze solved:");
            for (int i = path.size() - 1; i >= 0; i--) {
                System.out.println(path.get(i));
            }
        } else {
            System.out.println("No solution found for the maze.");
        }
    }
}
