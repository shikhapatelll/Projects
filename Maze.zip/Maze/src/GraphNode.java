// Represents a node (room) in the graph implementation of the maze
// Each node has a unique identifier (name) and can be marked during traversal

public class GraphNode {
	// Name is an integer between 0 and n-1, where n is the number of nodes
	private int name;
	// will be used to mark nodes during DFS traversal of the maze
	private boolean mark;

	// Creating a new node with the specified name.
	public GraphNode(int name) {
		this.name = name;
		this.mark = false; // Initially, node is unmarked
	}


	// Marks or unmarks this node during maze traversal.
	public void mark(boolean mark) {
		this.mark = mark;
		// mark true to mark the node, false to unmark it
	}


	 // Checks if this node has been marked during traversal.
	public boolean isMarked() {
		return mark;
		// returns true if the node is marked, false otherwise
	}

	// Gets the unique identifier of this node.
	public int getName() {
		return name;
		// returns the name (number) of this node
	}
	
}
