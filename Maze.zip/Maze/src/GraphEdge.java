// The GraphEdge class represents an edge in an undirected graph
// Each edge connects two nodes (endpoints) and stores additional properties, type and label
public class GraphEdge {

	// Instance variables to store the two endpoints of the edge
	private GraphNode endpoint1; // The first endpoint of the edge
	private GraphNode endpoint2; // The second endpoint of the edge

	// Instance variable to store the type of the edge.
	private int type; // The type can represent a weight, cost, or any integer property associated with the edge

	// Instance variable to store the label of the edge
	private String label; // The label provides a descriptive property, such as door or corridor


	// Constructor to initialize a new edge with its endpoints, type, and label
	public GraphEdge(GraphNode u, GraphNode v, int type, String label) {
		this.endpoint1 = u; // Assigning the first endpoint
		this.endpoint2 = v; // Assigning the second endpoint
		this.type = type; // Set the type of the edge
		this.label = label; // Set the label for the edge
	}

	// Method to retrieve the first endpoint of the edge
	public GraphNode firstEndpoint() {
		return endpoint1;
		// Returns the first endpoint of the edge
	}

	// Method to retrieve the second endpoint of the edge
	public GraphNode secondEndpoint() {
		return endpoint2;
		// Returns the second endpoint of the edge
	}

	// Method to retrieve the type of the edge
	public int getType() {
		return type;
		// Return the type of the edge
	}

	// Method to update the type of the edge
	public void setType(int newType) {
		// Sets the type of the edge to the specified value
		this.type = newType;
	}

	// Method to retrieve the label of the edge
	public String getLabel() {
		// Returns the label of the edge
		return label;
	}

	// Method to update the label of the edge
	public void setLabel(String newLabel) {
		// sets the label of the edge to the specified value
		this.label = newLabel;
	}
	
}
