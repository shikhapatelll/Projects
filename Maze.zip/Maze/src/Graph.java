import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// The Graph class represents an undirected graph using an adjacency list.
public class Graph implements GraphADT {
	private GraphNode[] nodes;
	// Array of all nodes in the graph
	private ArrayList<GraphEdge>[] adjacencyList;
	// Adjacency list to store edges connected to each node


	// This constructor will initialize the graph with 'n' nodes and no edges
	public Graph(int n) {
		nodes = new GraphNode[n]; // Creating an array to hold graph nodes
		adjacencyList = new ArrayList[n]; // Creating an array of adjacency lists

		for (int y = 0; y < n; y++) {
			nodes[y] = new GraphNode(y); // Initializing each node with a unique identifier
			adjacencyList[y] = new ArrayList<GraphEdge>(); // Initializing an empty adjacency list for each node
		}
	}


	// Method to insert an edge between two nodes with a given type and label
	@Override
	public void insertEdge(GraphNode u, GraphNode v, int edgeType, String label) throws GraphException {
		// Validating the nodes to ensure they exist and are within range
		if (u == null || v == null || u.getName() >= nodes.length || v.getName() >= nodes.length) {
			throw new GraphException("Invalid nodes"); // If validation fails, throw an exception with a meaningful error message
			// Checking if either of the nodes is null or if their indices are out of the valid range (0 to nodes.length - 1)
			// To ensures the nodes are valid and exist in the graph
		}

		// Checking if an edge already exists between the two nodes to prevents duplicate edges between the same pair of nodes
		if (areAdjacent(u, v)) {
			throw new GraphException("Edge already exists");
			// If an edge exists, throw an exception
		}

		// Creating a new edge object representing a connection between u and v, edge also stores the type
		GraphEdge edge = new GraphEdge(u, v, edgeType, label);
		// Adding the newly created edge to the adjacency list of u to establishes the connection from u to v in the graph representation
		adjacencyList[u.getName()].add(edge);
		// Adding the same edge to the adjacency list of v to ensure the graph is undirected, as the edge is stored for both nodes
		adjacencyList[v.getName()].add(edge);

	}

	// Method to retrieve a node by its identifier
	@Override
	public GraphNode getNode(int name) throws GraphException {
		// Checking if the node index is valid
		if (name < 0 || name >= nodes.length) {
			throw new GraphException("Invalid node index");
		}
		// Returning the node at the specified index
		return nodes[name];
	}

	// Method to retrieve all edges incident on a given node
	@Override
	public Iterator<GraphEdge> incidentEdges(GraphNode u) throws GraphException {
		// Checking if the provided node is null or its index is out of bounds
		if (u == null || u.getName() >= nodes.length) {
			throw new GraphException("Invalid node");
			// Throwing an exception if the node is invalid
		}

		// Retrieving the list of edges connected to the given node from the adjacency list
		ArrayList<GraphEdge> edges = adjacencyList[u.getName()];

		// If the node has no edges, return null
		if (edges.isEmpty()) {
			return null;
		}
		// Returns an iterator over the list of edges connected to the node
		return edges.iterator();
	}

	// Method to retrieve the edge connecting two specific nodes, if it exists
	@Override
	public GraphEdge getEdge(GraphNode u, GraphNode v) throws GraphException {

		// Checking if either of the nodes is null or if their indices are out of bounds
		if (u == null || v == null || u.getName() >= nodes.length || v.getName() >= nodes.length) {
			throw new GraphException("Invalid nodes");
			// Throwing an exception if the nodes are invalid
		}

		// Getting an iterator over the edges incident on the first node
		Iterator<GraphEdge> edges = incidentEdges(u);

		// If there are no edges connected to the first node, return null
		if (edges == null) return null;

		// Iterating through all the edges incident on the first node
		while (edges.hasNext()) {
			GraphEdge edge = edges.next(); // Gets the next edge from the iterator
			// Check if this edge connects the two given nodes, considering both directions
			if ((edge.firstEndpoint() == u && edge.secondEndpoint() == v) ||
					(edge.firstEndpoint() == v && edge.secondEndpoint() == u)) {
				return edge;
				// Returning the edge if it connects the two nodes
			}
		}
		return null;  // If no edge connects the given nodes, return null
	}

	// Method to check if two nodes are adjacent, connected by an edge
	@Override
	public boolean areAdjacent(GraphNode u, GraphNode v) throws GraphException {
		// Calling the getEdge method to determine if there is an edge between the two nodes
		return getEdge(u, v) != null;
		// If getEdge returns a non-null value, it means the nodes are adjacent
	}

}
