import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// The Maze class represents a maze using a graph
public class Maze {

	// The graph representation of the maze
	private Graph graph;

	// Index of the maze's entrance node
	private int startNode;

	// Index of the maze's exit node
	private int endNode;

	// Number of coins available to open doors
	private int coins;

	// Tracks the current path during DFS
	private ArrayList<GraphNode> currentPath;

	// Width of the maze, Added to store maze width
	private int labWidth;

	// Length of the maze, Added to store maze length
	private int labLength;


	// Constructor for the Maze class, initializing the maze from an input file
	public Maze(String inputFile) throws MazeException {
		try {
			// Creating a BufferedReader to read the maze data from the input file
			BufferedReader reader = new BufferedReader(new FileReader(new File(inputFile)));
			// helper method to process the input file and construct the maze
			readInput(reader);
			reader.close(); // Close the reader
		} catch (IOException | GraphException e) { // Catch exceptions related to file I/O or graph construction
			throw new MazeException(e.getMessage());
			// throwing MazeException with an appropriate error message
		}
	}

	// Method to retrieve the graph representation of the maze
	public Graph getGraph() throws MazeException {
		// Checking if the graph object has been initialized
		if (graph == null) {
			// If the graph is null, throwing a MazeException
			throw new MazeException("Graph not initialized");
		}
		// Returning the initialized graph object representing the maze
		return graph;
	}

	// Method to solve the maze and return an iterator of nodes along the solution path
	public Iterator<GraphNode> solve() {
		try {
			// Reset all nodes in the graph to be unmarked before starting the DFS traversal
			for (int a = 0; a < labWidth * labLength; a++) {
				graph.getNode(a).mark(false); // Unmark the node at index 'z'
			}

			// Initializing the currentPath list to store the nodes visited during the traversal
			currentPath = new ArrayList<>();

			// Start the DFS traversal from the entrance node (startNode) with the available number of coins
			return DFS(coins, graph.getNode(startNode));

		} catch (GraphException e) { // To catch exceptions related to graph operations
			return null;
			// Returning null if an exception occurs, indicating no solution was found
		}
	}

	// Private method to perform a Depth-First Search (DFS) traversal of the graph to solve the maze
	// k for number of coins available to open doors, go for the current node being explored
	private Iterator<GraphNode> DFS(int k, GraphNode go) throws GraphException {
		// Checking if the current node is null or already marked (visited)
		if (go == null || go.isMarked()) {
			return null;
			// If the node is invalid or visited, return null to backtrack
		}

		// Marking the current node as visited to prevent revisiting during this DFS path
		go.mark(true);
		// Adding the current node to the path being constructed
		currentPath.add(go);

		// Checking if the current node is the exit node (endNode)
		if (go.getName() == endNode) {
			// If the exit node is reached, return the path as a new iterator
			return new ArrayList<>(currentPath).iterator();
		}

		// Retrieving all edges incident on the current node
		Iterator<GraphEdge> edges = graph.incidentEdges(go);

		// If the current node has any incident edges, explore them
		if (edges != null) {
			// Iterating through each edge connected to the current node
			while (edges.hasNext()) {
				GraphEdge edge = edges.next(); // Get the next edge from the iterator

				GraphNode next = edge.firstEndpoint() == go ? // Determines the next node connected by the edge
						edge.secondEndpoint() : edge.firstEndpoint();  // and then checks which endpoint of the edge is not the current node and set it as 'next'

				// Proceeding if the next node has not been visited yet
				if (!next.isMarked()) {
					// Determines the number of coins needed to traverse this edge
					int coinsNeeded = edge.getLabel().equals("door") ? edge.getType() : 0;
					// If the edge represents a door, use its type as the coin cost; otherwise, cost is 0
					if (k >= coinsNeeded) { // Checking if the remaining coins are sufficient to traverse this edge
						Iterator<GraphNode> result = DFS(k - coinsNeeded, next);
						// Recursively calling DFS on the next node with updated coin count (subtracting coins used)

						// If a solution is found in the recursive call, return the solution path
						if (result != null) {
							return result;
						}
					}
				}
			}
		}

		// Backtrack,  Unmark the current node to allow it to be revisited in other DFS paths
		go.mark(false);
		// Removing the current node from the path as it does not lead to a solution
		currentPath.remove(currentPath.size() - 1);
		return null;
		// Return null to indicate no solution was found from this DFS branch
	}

	// Private method to read and parse the maze input file
	private void readInput(BufferedReader inputReader) throws IOException, GraphException {
		// Read maze parameters from the first four lines of the input file
		int scale = Integer.parseInt(inputReader.readLine().trim()); // Reads the scale factor
		labWidth = Integer.parseInt(inputReader.readLine().trim()); // Reads and stores the maze width
		labLength = Integer.parseInt(inputReader.readLine().trim()); // Reads and stores the maze length
		coins = Integer.parseInt(inputReader.readLine().trim()); // Reads and stores the number of coins available

		// Initializing graph with total number of rooms
		graph = new Graph(labWidth * labLength);

		// Creating a 2D character array to store the structure of the maze
		// The array size is calculated based on the grid's rows and columns
		char[][] maze = new char[2 * labLength - 1][2 * labWidth - 1];

		// Loop through each line of the maze structure to populate the 2D character array
		for (int a = 0; a < 2 * labLength - 1; a++) {
			String line = inputReader.readLine(); // Read the next line of the maze structure

			for (int b = 0; b < 2 * labWidth - 1; b++) {
				maze[a][b] = line.charAt(b); // Store the character in the maze array

				// Checking if the current character is the entrance 's' and set startNode
				if (maze[a][b] == 's') startNode = (a/2) * labWidth + (b/2);
				// Checking if the current character is the exit 'x' and set endNode
				if (maze[a][b] == 'x') endNode = (a/2) * labWidth + (b/2);
			}
		}

		// Process horizontal connections in the maze
		for (int a = 0; a < 2 * labLength - 1; a += 2) { // Skip every alternate row to focus on horizontal connections
			for (int b = 1; b < 2 * labWidth - 1; b += 2) { // Focus on characters between rooms horizontally
				char connection = maze[a][b]; // Read the character representing a connection

				// Checking if the connection is not a wall 'w'
				if (connection != 'w') {
					// Calculating the indices of the two rooms connected by this horizontal connection
					int node1 = (a/2) * labWidth + (b-1)/2; // Room to the left
					int node2 = (a/2) * labWidth + (b+1)/2; // Room to the right

					// Determines the label (corridor or door) and type (number of coins if door) for this connection
					String label = Character.isDigit(connection) ? "door" : "corridor"; // If digit, it's a door
					int type = Character.isDigit(connection) ? Character.getNumericValue(connection) : 0; // Coins needed
					// Inserting an edge into the graph for this connection
					insertEdge(node1, node2, type, label);
				}
			}
		}

		// Process vertical connections in the maze
		for (int a = 1; a < 2 * labLength - 1; a += 2) { // Focus on rows between rooms vertically
			for (int b = 0; b < 2 * labWidth - 1; b += 2) { // Skip alternate columns to focus on vertical connections
				// Read the character representing a connection
				char connection = maze[a][b];

				// Checking if the connection is not a wall
				if (connection != 'w') {
					// Calculating the indices of the two rooms connected by this vertical connection
					int node1 = ((a-1)/2) * labWidth + b/2;
					int node2 = ((a+1)/2) * labWidth + b/2;

					// Determines the label (corridor or door) and type (number of coins if door) for this connection
					String label = Character.isDigit(connection) ? "door" : "corridor"; // If digit, it's a door

					int type = Character.isDigit(connection) ? Character.getNumericValue(connection) : 0; // Coins needed

					// Inserting an edge into the graph for this connection
					insertEdge(node1, node2, type, label);
				}
			}
		}
	}

	// private method to add an edge between two nodes in the graph
	private void insertEdge(int node1, int node2, int linkType, String label) throws GraphException {
		graph.insertEdge(graph.getNode(node1), graph.getNode(node2), linkType, label);

	}

}
