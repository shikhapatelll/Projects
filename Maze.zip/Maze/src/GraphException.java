public class GraphException extends Exception {
  public GraphException(String mssg) {
    super(mssg);
  }
}