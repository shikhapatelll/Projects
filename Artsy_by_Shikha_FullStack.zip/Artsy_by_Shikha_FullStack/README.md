# Artsy by Shikha — Full-Stack Prototype

This package serves your original Artsy website via an **Express** server and adds:
- REST API: `GET /api/artworks` (optional `?q=...`)
- REST API: `POST /api/contact`
- SQLite database using **sql.js** (no native SQLite install needed)

## Run
```bash
cd server
npm install
npm start
```

Then open: http://localhost:5050

Generated: 2026-01-11
