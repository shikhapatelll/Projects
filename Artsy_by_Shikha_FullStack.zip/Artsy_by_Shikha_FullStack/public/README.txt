Artsy by Shikha — Final Project Web Site (DigiComm 2203A)

Folder structure:
Website/
  ├─ index.html        (Home)
  ├─ artworks.html     (My Artworks)
  ├─ services.html     (Services)
  ├─ community.html    (Community)
  ├─ contact.html      (Contact)
  ├─ style.css
  └─ images/           (original artwork / photos)

How to deploy to FIMS Instruct (per Final Project brief):

1) Upload the entire `Website` folder to your FIMS account using FileZilla.
   Destination path: /Website
   Public URL: https://instruct.fims.uwo.ca/YourUserId/Website
   (replace `YourUserId` with your own FIMS user ID).

2) Validate HTML:
   https://validator.w3.org/

3) Check accessibility:
   https://wave.webaim.org/

4) Zip the `Website` folder (including all sub-folders such as images and CSS)
   and submit the ZIP file to the Final Project Web Site assignment on OWL Brightspace.

Content & images:

- Each page contains at least 200 words of original text written by Shikha Patel.
- All images in /images are either original artwork by Shikha Patel or appropriately
  licensed resources. Their copyright / licensing details are documented
  in the site footer and/or this README.
