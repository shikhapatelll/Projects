(async function () {
  const grid = document.getElementById("artworks-grid");
  if (!grid) return;

  const params = new URLSearchParams(window.location.search);
  const q = params.get("q") || "";

  try {
    const resp = await fetch(`/api/artworks${q ? `?q=${encodeURIComponent(q)}` : ""}`);
    const data = await resp.json();

    grid.innerHTML = "";
    (data.items || []).forEach(item => {
      const card = document.createElement("div");
      card.className = "artwork-card";

      const img = document.createElement("img");
      img.src = item.image;
      img.alt = item.title;

      const title = document.createElement("div");
      title.className = "artwork-title";
      title.textContent = item.title;

      card.appendChild(img);
      card.appendChild(title);
      grid.appendChild(card);
    });
  } catch (e) {
    console.warn("Failed to load artworks from API:", e);
  }
})();
