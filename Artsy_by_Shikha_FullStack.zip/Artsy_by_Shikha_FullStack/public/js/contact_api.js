(async function () {
  const form = document.querySelector("form");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(form);

    const payload = {
      name: (formData.get("name") || formData.get("Name") || "").toString().trim(),
      email: (formData.get("email") || formData.get("Email") || "").toString().trim(),
      message: (formData.get("message") || formData.get("Message") || "").toString().trim()
    };

    if (!payload.name) payload.name = (document.querySelector('input[type="text"]')?.value || "").trim();
    if (!payload.email) payload.email = (document.querySelector('input[type="email"]')?.value || "").trim();
    if (!payload.message) payload.message = (document.querySelector('textarea')?.value || "").trim();

    let status = document.getElementById("contact-status");
    if (!status) {
      status = document.createElement("div");
      status.id = "contact-status";
      status.style.marginTop = "12px";
      form.appendChild(status);
    }

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        status.textContent = err.error || "Could not send message. Please try again.";
        return;
      }

      status.textContent = "Message sent! Thank you — I’ll get back to you soon.";
      form.reset();
    } catch (e) {
      status.textContent = "Network error. Please try again.";
    }
  });
})();
