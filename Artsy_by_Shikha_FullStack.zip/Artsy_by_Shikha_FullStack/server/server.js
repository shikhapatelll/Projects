const path = require("path");
const fs = require("fs");
const express = require("express");
const { initDb, getDb, persistDb, seedIfEmpty } = require("./db");

const app = express();
const PORT = process.env.PORT || 5050;

app.use(express.json({ limit: "2mb" }));

const publicDir = path.join(__dirname, "..", "public");
app.use(express.static(publicDir));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "artsy-fullstack", time: new Date().toISOString() });
});

app.get("/api/artworks", (req, res) => {
  const db = getDb();
  const q = (req.query.q || "").trim().toLowerCase();

  let rows = [];
  if (!q) {
    const stmt = db.prepare("SELECT id, title, image, tags FROM artworks ORDER BY id ASC");
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
  } else {
    const stmt = db.prepare(
      "SELECT id, title, image, tags FROM artworks WHERE lower(title) LIKE :q OR lower(tags) LIKE :q ORDER BY id ASC"
    );
    stmt.bind({ ":q": `%${q}%` });
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
  }

  rows = rows.map(r => ({
    id: r.id,
    title: r.title,
    image: r.image,
    tags: (r.tags || "").split(",").map(t => t.trim()).filter(Boolean)
  }));

  res.json({ items: rows });
});

app.post("/api/contact", (req, res) => {
  const { name, email, message } = req.body || {};
  if (!name || !email || !message) {
    return res.status(400).json({ ok: false, error: "Missing name, email, or message." });
  }

  const db = getDb();
  const stmt = db.prepare(
    "INSERT INTO contact_messages (name, email, message, created_at) VALUES (:name, :email, :message, :created_at)"
  );
  stmt.run({
    ":name": String(name).trim(),
    ":email": String(email).trim(),
    ":message": String(message).trim(),
    ":created_at": new Date().toISOString()
  });
  stmt.free();

  persistDb();
  res.json({ ok: true });
});

app.get("*", (req, res) => {
  const indexPath = path.join(publicDir, "index.html");
  if (fs.existsSync(indexPath)) return res.sendFile(indexPath);
  res.status(404).send("Not found");
});

(async () => {
  await initDb();
  await seedIfEmpty();
  app.listen(PORT, () => console.log(`Artsy full-stack server running on http://localhost:${PORT}`));
})();
