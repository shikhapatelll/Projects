const fs = require("fs");
const path = require("path");
const initSqlJs = require("sql.js");

let SQL = null;
let db = null;

const dataDir = path.join(__dirname, "data");
const dbFilePath = path.join(dataDir, "artsy.sqlite");
const seedArtworksPath = path.join(dataDir, "artworks.json");

function ensureDataDir() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
}

async function initDb() {
  ensureDataDir();
  SQL = await initSqlJs();

  if (fs.existsSync(dbFilePath)) {
    const filebuf = fs.readFileSync(dbFilePath);
    db = new SQL.Database(filebuf);
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS artworks (
      id INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      image TEXT NOT NULL,
      tags TEXT DEFAULT ''
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  persistDb();
}

function getDb() {
  if (!db) throw new Error("DB not initialized");
  return db;
}

function persistDb() {
  ensureDataDir();
  const data = db.export();
  fs.writeFileSync(dbFilePath, Buffer.from(data));
}

async function seedIfEmpty() {
  const result = db.exec("SELECT COUNT(*) AS c FROM artworks");
  const count = (result[0] && result[0].values && result[0].values[0] && result[0].values[0][0]) ? result[0].values[0][0] : 0;
  if (count > 0) return;

  let artworks = [];
  if (fs.existsSync(seedArtworksPath)) {
    artworks = JSON.parse(fs.readFileSync(seedArtworksPath, "utf8"));
  }

  const insert = db.prepare("INSERT INTO artworks (id, title, image, tags) VALUES (:id, :title, :image, :tags)");
  for (const a of artworks) {
    insert.run({
      ":id": a.id,
      ":title": a.title,
      ":image": a.image,
      ":tags": (a.tags || []).join(",")
    });
  }
  insert.free();
  persistDb();
}

module.exports = { initDb, getDb, persistDb, seedIfEmpty };
